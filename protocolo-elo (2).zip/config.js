
window.process = {
  env: {
    API_KEY: "YOUR_API_KEY",
  },
};
